# Lita Print Agent v1.0

A Windows tray print agent for Lita Pro. It exposes a local HTTP API and prints raw ESC/POS data to Windows USB/shared printers or network printers on port 9100.

## Included

- Windows tray application
- Local API at `http://127.0.0.1:17321`
- Receipt printing
- Kitchen/bar routing by `prepLocationId`
- Windows spooler RAW printing
- Network ESC/POS printing
- Failed-job queue with automatic retry
- Printer settings dashboard
- Logs in `C:\ProgramData\LitaPrintAgent\logs`
- PHP/JavaScript integration examples
- Inno Setup installer script

## Build

1. Install the .NET 8 SDK on Windows.
2. Install Inno Setup 6 if you want an EXE installer.
3. Run `build.bat`.
4. The self-contained application is created in `installer\publish`.
5. When Inno Setup is installed, `LitaPrintAgentSetup.exe` is generated automatically.

## First setup

1. Start `LitaPrintAgent.exe`.
2. Double-click its tray icon.
3. Add printer profiles in the table.
4. For a USB/shared printer use `Type=windows` and enter its exact Windows printer name.
5. For a network printer use `Type=network`, IP address, and port 9100.
6. Set a strong API key and use the same value in Lita Pro JavaScript.
7. Assign `PrepLocationId` for kitchen/bar routing.
8. Click **Test Selected**.

## API

- `GET /api/health` — no key required
- `GET /api/printers`
- `POST /api/printers/test`
- `POST /api/print/receipt`
- `POST /api/print/kitchen`
- `POST /api/print/raw`
- `POST /api/queue/retry`

Authenticated requests require either:

- `X-Lita-Agent-Key: your-key`
- `Authorization: Bearer your-key`

## Important browser note

A secure HTTPS Lita Pro website may be blocked from calling an insecure local HTTP endpoint by some browsers. Chrome normally allows loopback requests, but enterprise policies can differ. The production upgrade should add a localhost HTTPS certificate or a WebSocket/native messaging bridge.

## Current limitations

- QR code and logo raster printing are not yet included in this first source release.
- Printer status is based on print success/failure; many low-cost ESC/POS printers do not report reliable hardware status.
- This source was generated without a .NET compiler in the current environment, so build it on Windows and report any compiler error for correction.
