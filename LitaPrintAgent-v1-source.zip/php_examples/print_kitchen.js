async function printKitchenOrder(order) {
    const response = await fetch('http://127.0.0.1:17321/api/print/kitchen', {
        method: 'POST',
        headers: {'Content-Type':'application/json','X-Lita-Agent-Key':'change-this-secret'},
        body: JSON.stringify(order)
    });
    const result = await response.json();
    if (!response.ok || !result.success) throw new Error(result.message || 'Kitchen printing failed');
    return result;
}

printKitchenOrder({
    jobId: 'ORDER-9001',
    orderNumber: '9001',
    tableName: 'Table 4',
    customerName: 'Alilu',
    notes: 'Serve drinks first',
    items: [
        {prepLocationId:1,name:'Jollof Rice',quantity:2,unit:'plate',notes:'No pepper'},
        {prepLocationId:2,name:'Malt',quantity:2,unit:'bottle',notes:''}
    ]
}).catch(console.error);
