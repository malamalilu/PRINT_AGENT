<?php
header('Content-Type: application/json');
$url = 'http://127.0.0.1:17321/api/health';
$ch = curl_init($url);
curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 2]);
$result = curl_exec($ch);
if ($result === false) {
    http_response_code(503);
    echo json_encode(['success' => false, 'message' => 'Lita Print Agent is not running']);
} else {
    echo $result;
}
curl_close($ch);
