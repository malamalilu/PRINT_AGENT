async function printLitaReceipt(receiptData) {
    const response = await fetch('http://127.0.0.1:17321/api/print/receipt', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Lita-Agent-Key': 'change-this-secret'
        },
        body: JSON.stringify({
            printer: 'receipt',
            jobId: 'SALE-' + receiptData.invoiceNumber,
            openDrawer: true,
            cutPaper: true,
            content: receiptData
        })
    });
    const result = await response.json();
    if (!response.ok || !result.success) throw new Error(result.message || 'Printing failed');
    return result;
}

// Example
printLitaReceipt({
    companyName: 'LITA PRO',
    branchName: 'KUMASI - 3MASS',
    invoiceNumber: 'INV-10025',
    customerName: 'Walk-in Customer',
    cashier: 'Admin',
    items: [{ name: 'Fried Rice', quantity: 2, unitPrice: 40, total: 80 }],
    subtotal: 80,
    discount: 0,
    tax: 0,
    total: 80,
    paid: 100,
    change: 20,
    footer: 'Thank you for your business'
}).catch(console.error);
