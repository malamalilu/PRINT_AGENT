@echo off
setlocal
where dotnet >nul 2>nul || (echo Install .NET 8 SDK first.& pause & exit /b 1)
dotnet restore LitaPrintAgent\LitaPrintAgent.csproj
dotnet publish LitaPrintAgent\LitaPrintAgent.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o installer\publish
if errorlevel 1 pause
if exist "C:\Program Files (x86)\Inno Setup 6\ISCC.exe" "C:\Program Files (x86)\Inno Setup 6\ISCC.exe" installer\LitaPrintAgent.iss
pause
