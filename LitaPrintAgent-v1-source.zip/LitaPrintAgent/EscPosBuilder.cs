using System.Globalization;
using System.Text;

namespace LitaPrintAgent;

public static class EscPosBuilder
{
    private static readonly Encoding PrinterEncoding = Encoding.GetEncoding(437);

    public static byte[] Receipt(ReceiptContent c, int width, bool cut, bool drawer)
    {
        using var ms = new MemoryStream();
        void B(params byte[] b) => ms.Write(b);
        void T(string s) { var b = PrinterEncoding.GetBytes(s); ms.Write(b); }
        B(0x1B, 0x40);
        Center(B); Bold(B, true); Double(B, true); T(c.CompanyName + "\n"); Double(B, false); Bold(B, false);
        if (!string.IsNullOrWhiteSpace(c.BranchName)) T(c.BranchName + "\n");
        if (!string.IsNullOrWhiteSpace(c.Address)) T(c.Address + "\n");
        if (!string.IsNullOrWhiteSpace(c.Phone)) T("Tel: " + c.Phone + "\n");
        Left(B); T(Line(width));
        T($"Invoice: {c.InvoiceNumber}\n");
        T($"Date: {(c.Date ?? DateTime.Now):yyyy-MM-dd HH:mm}\n");
        T($"Customer: {c.CustomerName}\n");
        if (!string.IsNullOrWhiteSpace(c.Cashier)) T($"Cashier: {c.Cashier}\n");
        T(Line(width));
        foreach (var item in c.Items)
        {
            T(Wrap(item.Name, width));
            T($"{item.Quantity:0.##} x {item.UnitPrice:0.00}".PadRight(Math.Max(1, width - 12)) + $"{item.Total,12:0.00}\n");
        }
        T(Line(width));
        T(Money("Subtotal", c.Subtotal, width));
        if (c.Discount != 0) T(Money("Discount", c.Discount, width));
        if (c.Tax != 0) T(Money("Tax", c.Tax, width));
        Bold(B, true); Double(B, true); T(Money("TOTAL", c.Total, Math.Max(20, width / 2))); Double(B, false); Bold(B, false);
        if (c.Paid != 0) T(Money("Paid", c.Paid, width));
        if (c.Change != 0) T(Money("Change", c.Change, width));
        T(Line(width)); Center(B); T(c.Footer + "\n\n"); Left(B);
        if (drawer) B(0x1B, 0x70, 0x00, 0x19, 0xFA);
        if (cut) B(0x1D, 0x56, 0x00);
        return ms.ToArray();
    }

    public static byte[] Kitchen(string title, string order, string table, string customer, string notes, IEnumerable<KitchenItem> items, int width)
    {
        using var ms = new MemoryStream();
        void B(params byte[] b) => ms.Write(b);
        void T(string s) { var b = PrinterEncoding.GetBytes(s); ms.Write(b); }
        B(0x1B,0x40); Center(B); Bold(B,true); Double(B,true); T(title+"\n"); Double(B,false); Bold(B,false); Left(B);
        T(Line(width)); T($"Order: {order}\n"); T($"Time: {DateTime.Now:HH:mm:ss}\n");
        if (!string.IsNullOrWhiteSpace(table)) T($"Table: {table}\n");
        if (!string.IsNullOrWhiteSpace(customer)) T($"Customer: {customer}\n");
        T(Line(width)); Bold(B,true);
        foreach(var i in items) { T($"{i.Quantity:0.##} {i.Unit} {i.Name}\n"); if(!string.IsNullOrWhiteSpace(i.Notes)) T("  NOTE: "+i.Notes+"\n"); }
        Bold(B,false); if(!string.IsNullOrWhiteSpace(notes)){ T(Line(width)); T("ORDER NOTE: "+notes+"\n"); }
        T("\n\n"); B(0x1D,0x56,0x00); return ms.ToArray();
    }

    public static byte[] Text(string text, bool cut)
    {
        var data = new List<byte> { 0x1B, 0x40 };
        data.AddRange(PrinterEncoding.GetBytes(text + "\n"));
        if (cut) data.AddRange(new byte[] {0x1D,0x56,0x00});
        return data.ToArray();
    }

    private static string Line(int w) => new string('-', w) + "\n";
    private static string Money(string label, decimal amount, int w) { var a = amount.ToString("0.00", CultureInfo.InvariantCulture); return label.PadRight(Math.Max(1,w-a.Length))+a+"\n"; }
    private static string Wrap(string s,int w) => string.Join("\n", Enumerable.Range(0,(s.Length+w-1)/w).Select(i=>s.Substring(i*w,Math.Min(w,s.Length-i*w))))+"\n";
    private static void Center(Action<byte[]> b)=>b(new byte[]{0x1B,0x61,0x01});
    private static void Left(Action<byte[]> b)=>b(new byte[]{0x1B,0x61,0x00});
    private static void Bold(Action<byte[]> b,bool on)=>b(new byte[]{0x1B,0x45,(byte)(on?1:0)});
    private static void Double(Action<byte[]> b,bool on)=>b(new byte[]{0x1D,0x21,(byte)(on?0x11:0)});
}
