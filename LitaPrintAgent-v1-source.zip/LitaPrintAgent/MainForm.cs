namespace LitaPrintAgent;

public sealed class MainForm : Form
{
    private readonly SettingsStore _store; private readonly Func<AgentSettings> _get; private readonly Action<AgentSettings> _save; private readonly PrinterService _printers; private readonly JobQueue _queue; private readonly ApiServer _api;
    private readonly Label _status=new(); private readonly TextBox _port=new(),_key=new(); private readonly ComboBox _default=new(); private readonly DataGridView _grid=new();
    public MainForm(SettingsStore store,Func<AgentSettings> get,Action<AgentSettings> save,PrinterService printers,JobQueue queue,ApiServer api)
    {
        _store=store;_get=get;_save=save;_printers=printers;_queue=queue;_api=api;
        Text="Lita Print Agent";Width=900;Height=600;StartPosition=FormStartPosition.CenterScreen;
        var top=new FlowLayoutPanel{Dock=DockStyle.Top,Height=70,Padding=new Padding(10),AutoSize=false};
        top.Controls.AddRange(new Control[]{new Label{Text="API Port",AutoSize=true,Padding=new Padding(0,7,0,0)},_port,new Label{Text="API Key",AutoSize=true,Padding=new Padding(10,7,0,0)},_key,new Label{Text="Default Profile",AutoSize=true,Padding=new Padding(10,7,0,0)},_default});
        _port.Width=80;_key.Width=220;_default.Width=140;
        _grid.Dock=DockStyle.Fill;_grid.AutoGenerateColumns=true;_grid.AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill;
        var bottom=new FlowLayoutPanel{Dock=DockStyle.Bottom,Height=65,Padding=new Padding(10)};
        var saveBtn=new Button{Text="Save Settings",Width=120}; var testBtn=new Button{Text="Test Selected",Width=120}; var retryBtn=new Button{Text="Retry Queue",Width=110}; var logsBtn=new Button{Text="Open Logs",Width=100};
        _status.AutoSize=true;_status.Padding=new Padding(20,8,0,0);
        bottom.Controls.AddRange(new Control[]{saveBtn,testBtn,retryBtn,logsBtn,_status}); Controls.Add(_grid);Controls.Add(top);Controls.Add(bottom);
        saveBtn.Click+=(_,__)=>Save(); testBtn.Click+=async(_,__)=>await Test(); retryBtn.Click+=async(_,__)=>{await _queue.RetryAsync();RefreshStatus();}; logsBtn.Click+=(_,__)=>System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("explorer.exe",$"/select,\"{_store.LogPath}\""){UseShellExecute=true});
        LoadData();
    }
    private void LoadData(){var s=_get();_port.Text=s.ApiPort.ToString();_key.Text=s.ApiKey;_grid.DataSource=new BindingSource{DataSource=s.Printers};_default.DataSource=s.Printers.Select(x=>x.Name).ToList();_default.SelectedItem=s.DefaultPrinter;RefreshStatus();}
    private void Save(){_grid.EndEdit();var s=_get();if(int.TryParse(_port.Text,out var p))s.ApiPort=p;s.ApiKey=_key.Text.Trim();s.DefaultPrinter=_default.Text;_save(s);MessageBox.Show("Settings saved. Restart the agent after changing the API port.","Lita Print Agent");RefreshStatus();}
    private async Task Test(){if(_grid.CurrentRow?.DataBoundItem is not PrinterProfile p){MessageBox.Show("Select a printer profile.");return;}try{await _printers.PrintAsync(p,EscPosBuilder.Text("LITA PRINT AGENT\nTest print successful\n",true));MessageBox.Show("Test print sent.");}catch(Exception ex){MessageBox.Show(ex.Message,"Print failed");}}
    private void RefreshStatus()=>_status.Text=$"API: {(_api.IsRunning?"Running":"Stopped")}   Queue: {_queue.Count}";
}
