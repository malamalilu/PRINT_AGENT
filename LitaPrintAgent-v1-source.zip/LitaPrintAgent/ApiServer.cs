using System.Net;
using System.Text;
using System.Text.Json;

namespace LitaPrintAgent;

public sealed class ApiServer : IDisposable
{
    private readonly HttpListener _listener=new();
    private readonly Func<AgentSettings> _settings;
    private readonly PrinterService _printers;
    private readonly JobQueue _queue;
    private readonly SettingsStore _store;
    private CancellationTokenSource? _cts;
    public bool IsRunning => _listener.IsListening;
    public ApiServer(Func<AgentSettings> settings, PrinterService printers, JobQueue queue, SettingsStore store){_settings=settings;_printers=printers;_queue=queue;_store=store;}
    public void Start()
    {
        if(IsRunning)return; _listener.Prefixes.Clear(); _listener.Prefixes.Add($"http://127.0.0.1:{_settings().ApiPort}/"); _listener.Start(); _cts=new(); _=Loop(_cts.Token); _store.Log("API STARTED");
    }
    public void Stop(){try{_cts?.Cancel();_listener.Stop();}catch{} }
    private async Task Loop(CancellationToken token)
    {
        while(!token.IsCancellationRequested)
        {
            HttpListenerContext ctx; try{ctx=await _listener.GetContextAsync();}catch{break;} _=Handle(ctx);
        }
    }
    private async Task Handle(HttpListenerContext ctx)
    {
        AddCors(ctx.Response);
        if(ctx.Request.HttpMethod=="OPTIONS"){ctx.Response.StatusCode=204;ctx.Response.Close();return;}
        try
        {
            var path=ctx.Request.Url?.AbsolutePath.TrimEnd('/').ToLowerInvariant() ?? "";
            if(path=="/api/health") { await Json(ctx,200,new{success=true,status="running",version="1.0.0",queue=_queue.Count}); return; }
            if(!Authorized(ctx.Request)){await Json(ctx,401,new{success=false,message="Invalid API key"});return;}
            if(path=="/api/printers" && ctx.Request.HttpMethod=="GET") { await Json(ctx,200,new{success=true,windowsPrinters=_printers.WindowsPrinters(),profiles=_settings().Printers});return; }
            if(path=="/api/printers/test" && ctx.Request.HttpMethod=="POST") { var r=await Read<PrintRequest>(ctx); r.Text="LITA PRINT AGENT\nTest print successful\n"; await TryOrQueue("receipt",r,()=>_queue.PrintReceipt(r)); await Json(ctx,200,new{success=true,message="Test print accepted"});return; }
            if(path=="/api/print/receipt" && ctx.Request.HttpMethod=="POST") { var r=await Read<PrintRequest>(ctx); await TryOrQueue("receipt",r,()=>_queue.PrintReceipt(r)); await Json(ctx,200,new{success=true,message="Receipt accepted",jobId=r.JobId});return; }
            if(path=="/api/print/raw" && ctx.Request.HttpMethod=="POST") { var r=await Read<PrintRequest>(ctx); await TryOrQueue("receipt",r,()=>_queue.PrintReceipt(r)); await Json(ctx,200,new{success=true,message="Raw job accepted"});return; }
            if(path=="/api/print/kitchen" && ctx.Request.HttpMethod=="POST") { var r=await Read<KitchenPrintRequest>(ctx); await TryOrQueue("kitchen",r,()=>_queue.PrintKitchen(r)); await Json(ctx,200,new{success=true,message="Kitchen jobs accepted"});return; }
            if(path=="/api/queue/retry" && ctx.Request.HttpMethod=="POST") { await _queue.RetryAsync(); await Json(ctx,200,new{success=true,queue=_queue.Count});return; }
            await Json(ctx,404,new{success=false,message="Endpoint not found"});
        }
        catch(Exception ex){_store.Log("API ERROR "+ex);await Json(ctx,500,new{success=false,message=ex.Message});}
    }
    private bool Authorized(HttpListenerRequest req) { var key=req.Headers["X-Lita-Agent-Key"]; if(string.IsNullOrWhiteSpace(key) && req.Headers["Authorization"]?.StartsWith("Bearer ")==true) key=req.Headers["Authorization"]![7..]; return key==_settings().ApiKey; }
    private async Task<T> Read<T>(HttpListenerContext ctx){using var sr=new StreamReader(ctx.Request.InputStream,ctx.Request.ContentEncoding);var s=await sr.ReadToEndAsync();return JsonSerializer.Deserialize<T>(s,SettingsStore.JsonOptions()) ?? throw new InvalidOperationException("Invalid JSON body");}
    private async Task TryOrQueue(string kind,object payload,Func<Task> action){try{await action();}catch(Exception ex){_queue.Add(kind,payload,ex.Message);}}
    private static async Task Json(HttpListenerContext ctx,int status,object data){var b=Encoding.UTF8.GetBytes(JsonSerializer.Serialize(data,SettingsStore.JsonOptions()));ctx.Response.StatusCode=status;ctx.Response.ContentType="application/json";ctx.Response.ContentEncoding=Encoding.UTF8;ctx.Response.ContentLength64=b.Length;await ctx.Response.OutputStream.WriteAsync(b);ctx.Response.Close();}
    private static void AddCors(HttpListenerResponse r){r.Headers["Access-Control-Allow-Origin"]="*";r.Headers["Access-Control-Allow-Headers"]="Content-Type, Authorization, X-Lita-Agent-Key";r.Headers["Access-Control-Allow-Methods"]="GET, POST, OPTIONS";}
    public void Dispose()=>Stop();
}
