using System.Net.Sockets;
using System.Runtime.InteropServices;

namespace LitaPrintAgent;

public sealed class PrinterService
{
    private readonly Func<AgentSettings> _settings;
    private readonly SettingsStore _store;
    public PrinterService(Func<AgentSettings> settings, SettingsStore store) { _settings=settings; _store=store; }

    public IEnumerable<string> WindowsPrinters() => System.Drawing.Printing.PrinterSettings.InstalledPrinters.Cast<string>();

    public PrinterProfile Resolve(string name)
    {
        var s=_settings();
        var p=s.Printers.FirstOrDefault(x=>x.Name.Equals(name,StringComparison.OrdinalIgnoreCase));
        if(p==null && !string.IsNullOrWhiteSpace(s.DefaultPrinter)) p=s.Printers.FirstOrDefault(x=>x.Name.Equals(s.DefaultPrinter,StringComparison.OrdinalIgnoreCase));
        return p ?? throw new InvalidOperationException($"Printer profile '{name}' was not found.");
    }

    public async Task PrintAsync(PrinterProfile p, byte[] data)
    {
        if (p.Type.Equals("network", StringComparison.OrdinalIgnoreCase))
        {
            using var client=new TcpClient();
            await client.ConnectAsync(p.IpAddress,p.Port);
            await client.GetStream().WriteAsync(data);
            await client.GetStream().FlushAsync();
        }
        else
        {
            if(string.IsNullOrWhiteSpace(p.PrinterName)) throw new InvalidOperationException("Windows printer name is empty.");
            if(!RawPrinter.Send(p.PrinterName,data)) throw new InvalidOperationException("Windows spooler rejected the print job.");
        }
        _store.Log($"PRINT OK profile={p.Name} bytes={data.Length}");
    }
}

internal static class RawPrinter
{
    [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)] private class DOCINFO { [MarshalAs(UnmanagedType.LPWStr)] public string pDocName="Lita Pro Print Job"; [MarshalAs(UnmanagedType.LPWStr)] public string? pOutputFile=null; [MarshalAs(UnmanagedType.LPWStr)] public string pDataType="RAW"; }
    [DllImport("winspool.drv", SetLastError=true, CharSet=CharSet.Unicode)] static extern bool OpenPrinter(string pPrinterName,out IntPtr phPrinter,IntPtr pDefault);
    [DllImport("winspool.drv", SetLastError=true)] static extern bool ClosePrinter(IntPtr hPrinter);
    [DllImport("winspool.drv", SetLastError=true, CharSet=CharSet.Unicode)] static extern bool StartDocPrinter(IntPtr hPrinter,int level,[In] DOCINFO di);
    [DllImport("winspool.drv", SetLastError=true)] static extern bool EndDocPrinter(IntPtr hPrinter);
    [DllImport("winspool.drv", SetLastError=true)] static extern bool StartPagePrinter(IntPtr hPrinter);
    [DllImport("winspool.drv", SetLastError=true)] static extern bool EndPagePrinter(IntPtr hPrinter);
    [DllImport("winspool.drv", SetLastError=true)] static extern bool WritePrinter(IntPtr hPrinter,IntPtr pBytes,int dwCount,out int dwWritten);
    public static bool Send(string printer,byte[] bytes)
    {
        if(!OpenPrinter(printer,out var h,IntPtr.Zero)) return false;
        var p=Marshal.AllocCoTaskMem(bytes.Length); Marshal.Copy(bytes,0,p,bytes.Length);
        try { var ok=StartDocPrinter(h,1,new DOCINFO()); if(!ok)return false; StartPagePrinter(h); ok=WritePrinter(h,p,bytes.Length,out var written); EndPagePrinter(h); EndDocPrinter(h); return ok && written==bytes.Length; }
        finally { Marshal.FreeCoTaskMem(p); ClosePrinter(h); }
    }
}
