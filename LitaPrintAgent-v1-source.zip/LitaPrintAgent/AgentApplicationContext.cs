namespace LitaPrintAgent;

public sealed class AgentApplicationContext : ApplicationContext
{
    private readonly NotifyIcon _tray; private readonly SettingsStore _store=new(); private AgentSettings _settings; private readonly PrinterService _printers; private readonly JobQueue _queue; private readonly ApiServer _api; private MainForm? _form;
    public AgentApplicationContext()
    {
        _settings=_store.Load(); _printers=new PrinterService(()=>_settings,_store); _queue=new JobQueue(_store,_printers,()=>_settings); _api=new ApiServer(()=>_settings,_printers,_queue,_store);
        try{_api.Start();}catch(Exception ex){_store.Log("API START ERROR "+ex.Message);MessageBox.Show($"Could not start API on port {_settings.ApiPort}.\n{ex.Message}","Lita Print Agent");}
        var menu=new ContextMenuStrip(); menu.Items.Add("Dashboard",null,(_,__)=>ShowForm()); menu.Items.Add("Retry Queue",null,async(_,__)=>await _queue.RetryAsync()); menu.Items.Add("Open Logs",null,(_,__)=>System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("explorer.exe",Path.GetDirectoryName(_store.LogPath)!){UseShellExecute=true})); menu.Items.Add(new ToolStripSeparator()); menu.Items.Add("Exit",null,(_,__)=>Exit());
        _tray=new NotifyIcon{Text="Lita Print Agent",Icon=SystemIcons.Application,Visible=true,ContextMenuStrip=menu}; _tray.DoubleClick+=(_,__)=>ShowForm();
        Microsoft.Win32.SystemEvents.SessionEnding+=(_,__)=>Exit();
    }
    private void ShowForm(){if(_form==null||_form.IsDisposed){_form=new MainForm(_store,()=>_settings,s=>{_settings=s;_store.Save(s);},_printers,_queue,_api);_form.FormClosing+=(s,e)=>{if(e.CloseReason==CloseReason.UserClosing){e.Cancel=true;_form.Hide();}};}_form.Show();_form.WindowState=FormWindowState.Normal;_form.BringToFront();}
    private void Exit(){_tray.Visible=false;_api.Dispose();Application.Exit();}
}
