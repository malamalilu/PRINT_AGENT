namespace LitaPrintAgent;

public sealed class AgentSettings
{
    public int ApiPort { get; set; } = 17321;
    public string ApiKey { get; set; } = "change-this-secret";
    public string DefaultPrinter { get; set; } = "";
    public int RetrySeconds { get; set; } = 30;
    public List<PrinterProfile> Printers { get; set; } = new();
}

public sealed class PrinterProfile
{
    public string Name { get; set; } = "receipt";
    public string Type { get; set; } = "windows"; // windows|network
    public string PrinterName { get; set; } = "";
    public string IpAddress { get; set; } = "";
    public int Port { get; set; } = 9100;
    public int? PrepLocationId { get; set; }
    public int PaperWidth { get; set; } = 32;
}

public sealed class PrintRequest
{
    public string Printer { get; set; } = "receipt";
    public string? JobId { get; set; }
    public bool OpenDrawer { get; set; }
    public bool CutPaper { get; set; } = true;
    public ReceiptContent? Content { get; set; }
    public string? RawBase64 { get; set; }
    public string? Text { get; set; }
}

public sealed class KitchenPrintRequest
{
    public string? JobId { get; set; }
    public string OrderNumber { get; set; } = "";
    public string TableName { get; set; } = "";
    public string CustomerName { get; set; } = "";
    public string Notes { get; set; } = "";
    public List<KitchenItem> Items { get; set; } = new();
}

public sealed class KitchenItem
{
    public int PrepLocationId { get; set; }
    public string Name { get; set; } = "";
    public decimal Quantity { get; set; }
    public string Unit { get; set; } = "";
    public string Notes { get; set; } = "";
}

public sealed class ReceiptContent
{
    public string CompanyName { get; set; } = "LITA PRO";
    public string BranchName { get; set; } = "";
    public string Address { get; set; } = "";
    public string Phone { get; set; } = "";
    public string InvoiceNumber { get; set; } = "";
    public string CustomerName { get; set; } = "Walk-in Customer";
    public string Cashier { get; set; } = "";
    public DateTime? Date { get; set; }
    public List<ReceiptItem> Items { get; set; } = new();
    public decimal Subtotal { get; set; }
    public decimal Discount { get; set; }
    public decimal Tax { get; set; }
    public decimal Total { get; set; }
    public decimal Paid { get; set; }
    public decimal Change { get; set; }
    public string Footer { get; set; } = "Thank you for your business";
}

public sealed class ReceiptItem
{
    public string Name { get; set; } = "";
    public decimal Quantity { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal Total { get; set; }
}

public sealed class QueuedJob
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Kind { get; set; } = "receipt";
    public string PayloadJson { get; set; } = "";
    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public int Attempts { get; set; }
    public string LastError { get; set; } = "";
}
