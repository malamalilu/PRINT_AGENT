using System.Text.Json;

namespace LitaPrintAgent;

public sealed class JobQueue
{
    private readonly SettingsStore _store;
    private readonly PrinterService _printers;
    private readonly Func<AgentSettings> _settings;
    private readonly object _lock=new();
    private List<QueuedJob> _jobs;
    private readonly System.Threading.Timer _timer;

    public JobQueue(SettingsStore store, PrinterService printers, Func<AgentSettings> settings)
    {
        _store=store; _printers=printers; _settings=settings; _jobs=store.LoadQueue();
        _timer=new System.Threading.Timer(async _=>await RetryAsync(),null,TimeSpan.FromSeconds(10),TimeSpan.FromSeconds(Math.Max(10,settings().RetrySeconds)));
    }
    public int Count { get { lock(_lock)return _jobs.Count; } }
    public void Add(string kind, object payload, string error)
    {
        lock(_lock){ _jobs.Add(new QueuedJob{Kind=kind,PayloadJson=JsonSerializer.Serialize(payload,SettingsStore.JsonOptions()),LastError=error}); _store.SaveQueue(_jobs); }
        _store.Log($"QUEUED kind={kind} error={error}");
    }
    public async Task RetryAsync()
    {
        List<QueuedJob> copy; lock(_lock) copy=_jobs.ToList();
        foreach(var job in copy)
        {
            try
            {
                if(job.Kind=="receipt") { var r=JsonSerializer.Deserialize<PrintRequest>(job.PayloadJson,SettingsStore.JsonOptions())!; await PrintReceipt(r); }
                else if(job.Kind=="kitchen") { var r=JsonSerializer.Deserialize<KitchenPrintRequest>(job.PayloadJson,SettingsStore.JsonOptions())!; await PrintKitchen(r); }
                lock(_lock){_jobs.RemoveAll(x=>x.Id==job.Id);_store.SaveQueue(_jobs);} _store.Log($"QUEUE RETRY OK id={job.Id}");
            }
            catch(Exception ex){ lock(_lock){var j=_jobs.FirstOrDefault(x=>x.Id==job.Id);if(j!=null){j.Attempts++;j.LastError=ex.Message;}_store.SaveQueue(_jobs);} }
        }
    }
    public async Task PrintReceipt(PrintRequest r)
    {
        var p=_printers.Resolve(r.Printer); byte[] data;
        if(!string.IsNullOrWhiteSpace(r.RawBase64)) data=Convert.FromBase64String(r.RawBase64);
        else if(!string.IsNullOrWhiteSpace(r.Text)) data=EscPosBuilder.Text(r.Text,r.CutPaper);
        else data=EscPosBuilder.Receipt(r.Content ?? new ReceiptContent(),p.PaperWidth,r.CutPaper,r.OpenDrawer);
        await _printers.PrintAsync(p,data);
    }
    public async Task PrintKitchen(KitchenPrintRequest r)
    {
        foreach(var group in r.Items.GroupBy(x=>x.PrepLocationId))
        {
            var p=_settings().Printers.FirstOrDefault(x=>x.PrepLocationId==group.Key) ?? throw new InvalidOperationException($"No printer configured for prep location {group.Key}.");
            var data=EscPosBuilder.Kitchen("KITCHEN ORDER",r.OrderNumber,r.TableName,r.CustomerName,r.Notes,group,p.PaperWidth);
            await _printers.PrintAsync(p,data);
        }
    }
}
