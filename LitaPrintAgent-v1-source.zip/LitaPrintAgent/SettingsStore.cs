using System.Text.Json;

namespace LitaPrintAgent;

public sealed class SettingsStore
{
    private readonly string _baseDir;
    public string SettingsPath => Path.Combine(_baseDir, "appsettings.json");
    public string QueuePath => Path.Combine(_baseDir, "queue.json");
    public string LogPath => Path.Combine(_baseDir, "logs", $"agent-{DateTime.Now:yyyy-MM-dd}.log");

    public SettingsStore()
    {
        _baseDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "LitaPrintAgent");
        Directory.CreateDirectory(_baseDir);
        Directory.CreateDirectory(Path.Combine(_baseDir, "logs"));
    }

    public AgentSettings Load()
    {
        if (!File.Exists(SettingsPath))
        {
            var settings = new AgentSettings();
            settings.Printers.Add(new PrinterProfile { Name = "receipt", Type = "windows" });
            Save(settings);
            return settings;
        }
        return JsonSerializer.Deserialize<AgentSettings>(File.ReadAllText(SettingsPath), JsonOptions()) ?? new AgentSettings();
    }

    public void Save(AgentSettings settings) => File.WriteAllText(SettingsPath, JsonSerializer.Serialize(settings, JsonOptions()));

    public List<QueuedJob> LoadQueue()
    {
        if (!File.Exists(QueuePath)) return new();
        try { return JsonSerializer.Deserialize<List<QueuedJob>>(File.ReadAllText(QueuePath), JsonOptions()) ?? new(); }
        catch { return new(); }
    }

    public void SaveQueue(List<QueuedJob> queue) => File.WriteAllText(QueuePath, JsonSerializer.Serialize(queue, JsonOptions()));

    public void Log(string message)
    {
        try { File.AppendAllText(LogPath, $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} {message}{Environment.NewLine}"); } catch { }
    }

    public static JsonSerializerOptions JsonOptions() => new() { PropertyNameCaseInsensitive = true, WriteIndented = true };
}
