[Setup]
AppName=Lita Print Agent
AppVersion=1.0.0
DefaultDirName={autopf}\Lita Print Agent
DefaultGroupName=Lita Print Agent
OutputBaseFilename=LitaPrintAgentSetup
Compression=lzma
SolidCompression=yes
PrivilegesRequired=admin

[Files]
Source: "publish\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion

[Icons]
Name: "{group}\Lita Print Agent"; Filename: "{app}\LitaPrintAgent.exe"
Name: "{autodesktop}\Lita Print Agent"; Filename: "{app}\LitaPrintAgent.exe"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; Flags: unchecked
Name: "startup"; Description: "Start Lita Print Agent with Windows"; Flags: checkedonce

[Registry]
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "LitaPrintAgent"; ValueData: "\"{app}\LitaPrintAgent.exe\""; Tasks: startup

[Run]
Filename: "{app}\LitaPrintAgent.exe"; Description: "Launch Lita Print Agent"; Flags: nowait postinstall skipifsilent
